---
id: AD-001
title: Constraints Are Captured in the Adapter and Evaluated After Selection
summary: Constraint definitions and asserted usages are repo-owned model data, evaluated after variation selection and before artifact writes.
date: 2026-10-30
status: accepted
layers: [architecture, implementation]
state: docs/breakdown/02-architecture/model-structure.md
artifacts:
  - src/pyssp_sysml2/model/model.py
  - src/pyssp_sysml2/model/parser.py
  - src/pyssp_sysml2/model/loader.py
  - src/pyssp_sysml2/model/exporter.py
  - src/pyssp_sysml2/parameters/constraints.py
supersedes: []
superseded_by: []
related: []
---

# AD-001: Constraints Are Captured in the Adapter and Evaluated After Selection

## Context

Fixtures duplicated variation guard logic outside the adapter. SysML constraint
definitions, usages, and assert statements carried the same legality rule, but
the repo-owned model dropped them. `sysmlpy` exposed a checker, yet adopting it
would leak parser internals and widen the dependency pin.

## Decision

Chose option B on 2026-10-30: add constraint dataclasses to the repo-owned
model, capture them in `parser.py` and `loader.py`, preserve them in export, and
evaluate asserted usages in a small new `parameters/constraints.py` after
variation selection, before any artifact write.

## Rationale

The artifact boundary stays repo-owned and the sysmlpy pin stays untouched.
Capture at the adapter keeps generation paths free of parser types. Evaluating
after selection makes an illegal `--select` fail before output is written, so
fixtures can drop their duplicated guard.

## Alternatives Considered

- Call `sysmlpy.check_constraints` directly.
- Keep constraint checks in each fixture as a local guard.

## Consequences

- Positive: one legality check shared by SSD, SSP, and analysis generation.
- Positive: exported SysML no longer erases constraints.
- Negative: the evaluator supports only the documented boolean subset and
  rejects anything outside it as invalid.

## Verification

`tests/test_constraints.py` covers capture, pass, fail, invalid, and unasserted
results. `tests/test_constraints_roundtrip.py` covers export. The CLI test
proves an illegal selection writes no SSD. The full suite stayed green.

## Review Trigger

Revisit when the constraint dialect needs operators, arithmetic, or types
beyond the documented subset.
