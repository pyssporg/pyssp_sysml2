---
id: AD-002
title: Analyses Declare Their Variation Selection with a Control Attribute
summary: A pyssp_selection control attribute on an Analysis is the single authored selection; the adapter resolves it and classifies each analysis as legal, violated, or invalid.
date: 2026-10-30
status: accepted
layers: [architecture, implementation]
state: docs/breakdown/02-architecture/model-structure.md
artifacts:
  - src/pyssp_sysml2/core/control.py
  - src/pyssp_sysml2/parameters/selection.py
  - src/pyssp_sysml2/parameters/variation.py
  - src/pyssp_sysml2/parameters/constraints.py
  - src/pyssp_sysml2/artifacts/analysis.py
  - src/pyssp_sysml2/artifacts/ssd.py
  - src/pyssp_sysml2/artifacts/ssp.py
supersedes: []
superseded_by: []
related: [AD-001]
---

# AD-002: Analyses Declare Their Variation Selection with a Control Attribute

## Context

Every variation fixture repeated its selection matrix in `build.py`, translated
the matrix into two key scopes, and re-implemented the adapter's legality
predicate. The analysis already is the authored combination; only the selection
was kept outside SysML. Variation also accepted bare keys while constraints
required the exact binding path, and a model build required every composing
analysis's attribute point.

## Decision

An Analysis declares its selection with
`attribute pyssp_selection = "key=variant;key=variant";`.
`parameters/selection.py` resolves it and returns a plan with status `legal`,
`violated`, or `invalid`; an explicit `--select` wins.
`variation.resolve_selected` canonicalizes the keys once for variation and
constraint evaluation, and required points are scoped to the target.

## Rationale

The architecture becomes the single source of the selection, while the fixture
keeps only its claim: the expected legal and violated analyses. The `pyssp_`
prefix keeps the attribute out of every artifact, and the value needs no new
parser grammar.

## Alternatives Considered

- One `pyssp_select_<point>` attribute per point: awkward for dotted keys.
- Infer the selection from which `bind` paths resolve: heuristic and ambiguous.
- Keep the external matrix in `build.py`: duplicates the architecture.

## Consequences

- Positive: one authored source for a selection; fixtures stop assembling two
  key scopes.
- Positive: variation and constraints share one canonical key language.
- Positive: a model build no longer depends on unrelated analyses.
- Negative: `pyssp_selection` is a dialect addition and must be validated.
- Negative: `build_fixture` takes one selection map per analysis instead of the
  previous two-scope mapping.

## Verification

`tests/test_selection.py` covers parsing, plan statuses, the authored default,
and explicit override. `tests/test_variation.py` proves a model build no longer
requires an analysis attribute point. The full suite stayed green.

## Review Trigger

Revisit when a selection needs more structure than `key=variant` pairs, or when
a workflow must choose among several authored selections per analysis.
