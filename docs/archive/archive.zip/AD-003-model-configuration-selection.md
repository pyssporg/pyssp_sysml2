---
id: AD-003
title: Configurations derive the analysis selection
summary: An analysis composes a model-level SysML v2 configuration; the adapter derives the selection map from its redefinitions and feature values, replacing the pyssp_selection control attribute.
date: 2026-10-30
status: accepted
layers: [architecture, implementation]
state: docs/breakdown/02-architecture/selection-and-plans.md
artifacts:
  - src/pyssp_sysml2/parameters/configuration.py
  - src/pyssp_sysml2/parameters/selection.py
  - src/pyssp_sysml2/parameters/variation.py
  - src/pyssp_sysml2/parameters/constraints.py
  - src/pyssp_sysml2/core/control.py
  - src/pyssp_sysml2/artifacts/analysis.py
supersedes: [AD-002]
superseded_by: []
related: [AD-001]
---

# AD-003: Configurations derive the analysis selection

## Context

`AD-002` encoded the selection as a custom string attribute. SysML v2's standard
idiom is a 100% configuration: specialise the family and bind each variation
usage with a redefinition and a feature value. The string also could not express
that an inner point exists only after the outer variant is selected.

## Decision

An analysis composes a configuration part definition that specialises the root.
`parameters/configuration.py` walks the specialisation chain, replays every
redefinition onto the root's members, descends into a selected variant's type,
and returns the canonical map; an unbound point or an unknown variant is an
error. `pyssp_selection` is removed.

## Rationale

The selection is structural SysML, ordered by construction, and the derived map
reuses `resolve_selected` and constraint evaluation unchanged. A typo becomes a
model error naming the point, not a malformed string.

## Alternatives Considered

- Keep the control attribute: custom, stringly typed, and unable to order
  nested bindings.
- Generate the specialised composition directly: larger blast radius and a new
  artifact identity for every configuration.

## Consequences

- Positive: one standard authoring form; nested points cannot be bound without
  their outer variant.
- Positive: plans expose the configuration name as provenance.
- Negative: analysis generation retypes `sut` to the root, so a configuration
  name is not a generation target.

## Verification

`tests/test_selection.py` covers simple, conditional, nested, unbound-inner, and
analysis-local derivation plus the plan statuses; the full suite and `ruff`
pass. The SysML text is asserted through the selection fixture.
The constraint walk now evaluates inherited asserted usages, so the conditional
configuration's illegal analysis reports `violated` against the family's assert.
Analysis generation retypes `sut` to the root, so inherited parts and parameter
binds resolve; a configuration name is rejected as a generation target.

## Review Trigger

Revisit if SysML v2 standardises a selection construct, or if a configuration
must also contribute structure beyond the selected variant's declared type.
