---
id: AD-004
title: pyssp_sysml2 Becomes an SSP-Artifact Implementer
summary: At v0.4.0 pyssp_sysml2 keeps only SSP-family emission and SSD-to-SysML synthesis; the SysML dialect moved to pycps_sysml2 and FMI to pyfmi_sysml2.
date: 2026-11-05
status: accepted
layers: [implementation, verification, operation]
state: docs/breakdown/03-implementation/module-map.md
artifacts:
  - docs/breakdown/03-implementation/module-map.md
  - docs/breakdown/05-operation/migration-to-0.4.md
  - docs/breakdown/06-evolution/fmi-model-exchange-and-fmi3.md
  - pyproject.toml
  - src/pyssp_sysml2/__init__.py
  - src/pyssp_sysml2/cli.py
supersedes: []
superseded_by: []
related: [AD-001, AD-003]
---

# AD-004: pyssp_sysml2 Becomes an SSP-Artifact Implementer

## Context

`pyssp_sysml2` had grown a SysML parser, dialect, variation, selection, constraints, and FMI emission alongside the SSP writers it exists for. `pycps_sysml2` now needs the same model without depending on this package's CLI, and `pyfmi_sysml2` needs the FMI metadata. One release had to move the shared code without breaking existing `pyssp_sysml2.<package>` imports.

## Decision

On 2026-11-05, v0.4.0 became SSP-artifact-only: the SysML dialect, IR, names, exporter, variation, markers, parameter resolution, selection, and constraints moved to `pycps_sysml2` 0.1.0, which pins `sysmlpy==0.96.4`; FMI model descriptions, C headers, Modelica connectors, and FMU packaging moved to `pyfmi_sysml2` 0.1.0.
`pyssp_sysml2` keeps SSD/SSV/SSM/SSP/analysis emission, SSD-to-SysML synthesis and sync, `core/paths.py`, `parameters/synthesis/`, and the CLI.
Every moved import path stays as a one-line re-export shim for one minor release and is removed in v0.5.0.
`pyssp_flat_connector = false` now means not flattened; the old presence read that flattened anyway was fixed deliberately.

## Rationale

One owner per concern: `pycps_sysml2` owns the language and resolution, `pyfmi_sysml2` owns FMI, and this package owns SSP artifacts. A one-minor shim window keeps downstream imports working while they move. The flat-connector read was a bug: the attribute value, not its presence, must decide flattening.

## Alternatives Considered

- Keep parser, dialect, and FMI here and let `pyfmi_sysml2` import `pyssp_sysml2`: couples FMI to an SSP CLI and keeps the language owner split.
- Hard break at v0.4.0 with no shims: cleaner, but breaks every consumer in the same release.
- Preserve the presence-based flat-connector read: keeps a documented attribute value meaningless.

## Consequences

- Positive: each concern has one package and one release cadence.
- Positive: `pyssp_sysml2` no longer imports `sysmlpy` or generates FMI.
- Positive: `pyssp_flat_connector = false` now behaves as documented.
- Negative: moved imports work only until v0.5.0, and the shims are dead code meanwhile.
- Negative: the retired `EVAL-001` and `EVAL-002` parser evaluations now belong to `pycps_sysml2`; their files were removed from this tree.
- Negative: FMI Model Exchange and FMI 3.0 have no owner after the split (`IMP-016`).

## Verification

`tests/test_module_layout.py` is a static gate over the package root, the shim list, shim contents, and the absence of a `sysmlpy` import (`TEST-002`). `tests/test_cli.py` covers the `generate fmi` error path and exit code. The artifact and round-trip suites stay in this repository; parser, model, variation, and selection suites moved with `pycps_sysml2`.

## Review Trigger

Revisit at v0.5.0 when the shims are removed, or when `pyfmi_sysml2` takes on Model Exchange or FMI 3.0.
